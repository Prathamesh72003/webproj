<?php
define('MERCHENT_KEY', 'tmPAeC45iwQQeNO2');
define('MERCHENT_MID', 'CAKYrG41013971179833');
define('ENV', 'TEST');


